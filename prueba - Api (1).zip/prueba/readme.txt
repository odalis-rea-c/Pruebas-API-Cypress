#Preparación de ambiente
1. npm i
2. npx cypress open
3. Se abre el CYPRESS STUDIO, elegir el navegador
4. Seleccionar el Caso de prueba
5. Ejecutar


#Las instrucciones paso a paso de la ejecución
1. Acceder a la Página de Registro
La URL de la API es una variable de entorno para acceder al sitio de DemoBlaze.

2. Crear un nuevo usuario en Signup: Verifica que se pueda registrar un nuevo usuario con la API de signup.

3. Acceder a la Página de Login

4. Intentar crear un usuario ya existente: Verifica que la API de signup devuelva un error cuando se intenta registrar un usuario que ya existe.

5. Usuario y contraseña correctos en Login: Verifica que se pueda iniciar sesión con un usuario y contraseña válidos.

6. Usuario y contraseña incorrectos en Login: Verifica que se devuelva un error si el usuario o la contraseña son incorrectos.


