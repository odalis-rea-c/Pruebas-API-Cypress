describe('Prueba de Login con usuario y contraseña correctos', () => {
    const apiUrl = 'https://api.demoblaze.com/login'; // URL de la API de Login
    const username = 'usuarioValido'; // Nombre de usuario registrado
    const password = 'ContraseñaValida123'; // Contraseña del usuario válido
  
    it('TC: Usuario y contraseña correctos en login', () => {
      // Realizar la solicitud de login con usuario y contraseña correctos
      cy.request({
        method: 'POST',
        url: apiUrl,
        body: {
          username: username, // Nombre de usuario válido
          password: password  // Contraseña válida
        }
      }).then((response) => {
        // Imprime la respuesta completa para inspeccionarla
        cy.log('Respuesta completa:', JSON.stringify(response.body));
  
        // Verificamos que la respuesta sea exitosa (código 200)
        expect(response.status).to.eq(200); // El código de estado debe ser 200
  
        // Verifica si la respuesta contiene alguna propiedad esperada
        // Puedes ajustar esto según el formato real de la respuesta
        if (response.body.hasOwnProperty('message')) {
          // Si el mensaje existe, validamos su contenido
          expect(response.body.message).to.include('Login successful'); // Mensaje de éxito en el login
        } else {
          // Si no existe un mensaje, revisamos otras posibles propiedades de éxito
          cy.log('La respuesta no contiene la propiedad "message". Verifica el formato de la respuesta.');
        }
  
        // Si la respuesta contiene un token o información adicional, también puedes verificarlo
        // Por ejemplo:
        // expect(response.body).to.have.property('token'); // Si hay un token
      });
    });
  });
  