describe('Prueba de Signup para crear un nuevo usuario', () => {
    const apiUrl = 'https://api.demoblaze.com/signup'; // URL correcta de la API de Signup
    const username = 'nuevoUsuario'; // Nombre de usuario a crear
    const password = 'Contraseña123'; // Contraseña para el nuevo usuario
  
    it('TC: Crear un nuevo usuario en Signup', () => {
      cy.request({
        method: 'POST', // Indicamos que la solicitud será POST
        url: apiUrl, // URL de la API
        body: {
          username: username, // Nombre de usuario
          password: password  // Contraseña
        },
        failOnStatusCode: false // Para evitar que Cypress falle en caso de un error (200/400)
      }).then((response) => {
        // Imprimir la respuesta completa para depuración
        console.log(response.body);
        
        // Verificar que el código de estado sea 200
        expect(response.status).to.eq(200); // El código de estado debe ser 200
        
        // Verificar la propiedad 'errorMessage' o la estructura correcta
        expect(response.body).to.have.property('errorMessage'); // Cambiar la validación según la respuesta correcta
      });
    });
  });
  