describe('Prueba de Login con usuario y contraseña incorrectos', () => {
    const apiUrl = 'https://api.demoblaze.com/login'; // URL de la API de Login
    const username = 'usuarioIncorrecto'; // Nombre de usuario incorrecto
    const password = 'ContraseñaIncorrecta123'; // Contraseña incorrecta
  
    it('TC: Usuario y contraseña incorrectos en login', () => {
      // Realizar la solicitud de login con usuario y contraseña incorrectos
      cy.request({
        method: 'POST',
        url: apiUrl,
        body: {
          username: username, // Nombre de usuario incorrecto
          password: password  // Contraseña incorrecta
        },
        failOnStatusCode: false  // No fallar la prueba por un código de estado diferente a 200
      }).then((response) => {
        // Imprime la respuesta completa para inspeccionarla
        cy.log('Respuesta completa:', JSON.stringify(response.body));
  
        // Verificamos que la respuesta tenga un código de estado 200
        expect(response.status).to.eq(200); // El código de estado puede ser 200, aunque sea incorrecto
  
        // Verificar que el cuerpo de la respuesta contenga el mensaje de error adecuado
        expect(response.body).to.have.property('errorMessage'); 
        expect(response.body.errorMessage).to.include('User does not exist.'); // Ajusta el mensaje según el error esperado
      });
    });
  });
  