describe('Prueba de Signup para crear un usuario ya existente', () => {
    const apiUrl = 'https://api.demoblaze.com/signup'; // URL de la API de Signup
    const existingUsername = 'usuarioExistente'; // Usuario que ya está registrado
    const password = 'Contraseña123'; // Contraseña para el nuevo usuario
  
    it('TC: Intentar crear un usuario ya existente', () => {
      // Primero, intentamos crear el usuario ya existente
      cy.request({
        method: 'POST',
        url: apiUrl,
        body: {
          username: existingUsername, // Nombre de usuario que ya está registrado
          password: password // Contraseña para el nuevo usuario
        },
        failOnStatusCode: false // No falla si la respuesta es 400 o 500
      }).then((response) => {
        // Imprimir la respuesta para verificar el contenido
        console.log(response.body);
  
        // Verificamos que la respuesta contiene un mensaje de error
        expect(response.body).to.have.property('errorMessage'); 
        expect(response.body.errorMessage).to.include('This user already exist.'); // Cambiar a la cadena correcta
      });
    });
  });
  