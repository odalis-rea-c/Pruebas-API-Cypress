import { defineConfig } from 'cypress';

export default defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      const baseUrl = config.env.BASEURL_DEV; //implement node event listeners here
      config.baseUrl = baseUrl; //assign baseUrl from environment
      return config; //return the modified CONFIG
    },
  },
});
